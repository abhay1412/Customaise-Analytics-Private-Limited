from fastapi import FastAPI
import pandas as pd  # for dataframe manipulation

app = FastAPI()  # create a FastAPI instance:

# reading csv file with pd.read_csv() in pandas
df = pd.read_csv("data.csv")

'''
function bucket(element)
input : each element from  dataframe of column 'experience_bucket'
:returns string of ranges of bucket of size 10 ex- 0-10, 11-20, 21-30, 31-40, etc

 
'''


def bucket(element):
    if 'Year' in element:
        year = element.split(' ')[0]
        if int(year) > 10:
            return str(int(year) // 10 * 10 + 1) + '-' + str(int(year) // 10 * 10 + 10)
        else:
            return '0-10'
    else:
        return '0-10'

# calling the fuction bucket on each element of series 'experienceMas'
df['experience_bucket'] = df['experienceMas'].apply(bucket)

# Counting the occurance of each bucket range over the dataframe with groupby() and count() methods
experience_bucket_count_dict = df.groupby('experience_bucket')['candidateName'].count()

# storing the grouped result into a dictonary for later use
experience_bucket_count_dict = experience_bucket_count_dict.to_dict()


@app.get("/")  # define a path operation decorator:
# This function will be called by FastAPI whenever it receives a request to the specified URL (/) using a GET operation.
# In this case, it is an async function.
async def root(): # define the path operation function
    return experience_bucket_count_dict
