steps to run the customer_data.py
extract the folder then

1. from cli

S1.make sure you have python3 installed if not install it from the below link

https://www.python.org/ftp/python/3.10.0/python-3.10.0-amd64.exe

S2. Install requirenment libraries run

pip install -r requirenments.txt

S3. run the file 

python customer_data.py
