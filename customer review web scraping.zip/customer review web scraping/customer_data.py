'''
Reason of choices :
I am choosing BeautifulSoup for this assignment because of it's simplicity for simple and short projects like these.

Explaination of steps :

1. Importing necessary libraries
2. Initializing the given url and Header(optional) and lists for data storage
3. requesting the pages that contain reviews for the said item with a while loop which will iterate over different pages containing customer reviews
4. searching for the the division which contain all review detail on a given page and iterating over all the inner data it contain with a for loop and findall()
5. serching for the specific information inside the individual data with find()
6. storing the requird data as a list element.
7. breaking the loop when all the reviews are found
6. Storing the final lists as python Dictionary elements.
7. Converting the Dictionary to a DataFrame with Pandas.DataFrame()
8. Storing the Dataframe into a csv file with pd.to_csv() method.

'''

# importing libraries
import requests  # used for sending request to the server for the html data
from bs4 import BeautifulSoup  # a Python library for pulling data out of HTML and XML files.
import pandas as pd  # for converting list to dataframe and to a csv file

# Given url for scrapping
url = "https://www.amazon.in/LG-24-inch-Monitor-Freesync-Borderless/product-reviews/B08J5Y9ZSV/ref" \
      "=cm_cr_getr_d_paging_btm_next_2?pageNumber= "

# HTTP headers let the client and the server pass additional information with an HTTP request or response.
# A he
HEADERS = ({'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) \
            AppleWebKit/537.36 (KHTML, like Gecko) \
            Chrome/90.0.4430.212 Safari/537.36',
            'Accept-Language': 'en-US, en;q=0.5'})

# Initializing list to store scraped data

name = []  # Stores names of reviewers
review = []  # Stores reviews of the particular reviewers
date = []  # Stores dates the reviews where posted

page_num = 1  # variable for initializing page number

while page_num < 50:  # loop to visit review pages iteratively
    html_data = requests.get(
        url + str(page_num))  # Stores the html data sent by the server for the particular requested page
    soup = BeautifulSoup(html_data.text, 'html.parser') # BeautifulSoup object, which represents the document as a
    # nested data structure for further ease in searching.

    # iterating over specific division in the parsed html data which contain all the required information
    for items in soup.find_all("div", class_="a-section review aok-relative"):

        # initializing variable which will temporarily store the needed information
        name_str = ''
        review_Str = ''
        date_str = ''

        # checking if the item contains data or not
        if items != '':

            # locating specific information with help of html tags
            name_str = items.find("span", class_="a-profile-name").text
            name.append(name_str) # appending the data in the specific list for further processing
            review_str = items.find("span", class_="a-size-base review-text review-text-content").text
            review.append(review_str.replace('\n', '').strip()) # remove \n and extra spaces
            date_str = items.find("span", class_="a-size-base a-color-secondary review-date").text
            date.append(date_str[21:]) # the date is after first 21 element of the string
        else:
            # if the item variable does not contain data then increase the page_num variable to break the while loop
            # since we have exhausted all reviews.
            page_num = 100
    page_num += 1


# storing all lists in a dictionary data structure for further conversion
# into a dataframe via DataFrame method in pandas

data = {'name': name, 'date': date, 'reviews': review}
df = pd.DataFrame(data)

# converting the dataframe into a csv file
df.to_csv('customer_reviews.csv')
